package part1;

// ���� Ŭ����
public class EmployeeHandler {
	private Employee[] empList; // = new Employee[100];
	private int cnt;

	public EmployeeHandler(int n) {
		empList = new Employee[n];
		cnt = 0;
	}

	public void addEmployee(Employee employee) {
		empList[cnt++] = employee;
	}

	public void showAllSalaryInfo() {
		for (int i = 0; i < cnt; i++) {
			empList[i].showSalaryInfo();
			System.out.println("-----------------");
		}
	}
	public void showTotalSalary() {
		int sum = 0;
		for (int i=0; i<cnt ; i++) { 
			sum+=empList[i].getPay(); // ������
		}
		System.out.println("�̴� �ѱ޿��� " + sum);

	}
}
