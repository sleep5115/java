package ex0622;

public class HybridWaterCar extends HybridCar {
	private int water; // ����

	public HybridWaterCar(int i, int j, int k) {
	super(i,j);
	this.water = k;
	}
	@Override
	public void showGaugeInfo() {
		super.showGaugeInfo(); // super.showGuageInfo();
		System.out.println("�� : " + water + "����");
	}	
}
