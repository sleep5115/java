package ex0622;

public class HybridCar extends Car {
	private int electric; // ����
	public HybridCar(int i, int j) {
		super(i);
		this.electric=j;
	}
	@Override
	public void showGaugeInfo() {
		super.showGaugeInfo();
		System.out.println("���� : " + electric + "kw");
	}
}
