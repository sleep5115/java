package Ex0621_1;
public class Main {
	public static void main(String[] args) {
		Person p1 = new Person("kim",20);
		p1.showPersonInfo(); // kim, 20 ���
		System.out.println("---");
		
		Student s1 = new Student("cha",18,11);
		s1.showStudentInfo(); // kim, 20 ���
		System.out.println("---");
		
		PartTimeStd pts= new PartTimeStd("lee",22,11,8,8000);
		pts.showPartTimeStdInfo(); // lee, 22, 11, 6400�� ���
	}
}
