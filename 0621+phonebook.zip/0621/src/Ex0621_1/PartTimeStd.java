package Ex0621_1;

public class PartTimeStd extends Student {
	private int hour; // ���� �ð�
	private int pay; // �ð��� �޿�
	
	public PartTimeStd(String name, int age, int sNo, int hour, int pay) {
		super(name,age,sNo);
		this.hour = hour;
		this.pay = pay;
	}

	public void showPartTimeStdInfo() {
		showStudentInfo();
		System.out.println("hour = " + hour);
		System.out.println("pay = " + pay);
	}

}
